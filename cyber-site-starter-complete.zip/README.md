# CyberAtlas Starter (Complete)

Minimal but complete scaffold for a research-grade, API-friendly cybersecurity site.
- Pico CSS, dark-first, accessible nav, command palette
- Cloudflare Pages Functions APIs: `/api/v1/*`
- Strict security headers via middleware
- Schemas (JSON Schema), sample data, ETL stubs, validation
- Static RSS feed + JSON endpoints
- CI workflow with validation + link check

## Quick Start
1) Install Wrangler: `npm i -g wrangler`
2) Dev: `wrangler pages dev public --compatibility-date=2025-08-01`
3) Deploy: `wrangler pages deploy public`

Functions live in `/functions`. APIs include `/api/v1/search`, `/api/v1/advisories`, `/api/v1/stats`.
