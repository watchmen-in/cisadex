# Contributing
- Use Conventional Commits.
- Include a11y notes, perf impact, and test plan in PRs.
- Run `node scripts/etl/validate.mjs` before pushing.
