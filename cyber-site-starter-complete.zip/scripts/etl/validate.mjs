// scripts/etl/validate.mjs
import fs from 'node:fs/promises';
import Ajv from 'ajv';
const ajv = new Ajv({ strict:false, allErrors:true });
const entitySchema = JSON.parse(await fs.readFile('src/data/schemas/entity.schema.v1.json','utf8'));
const entities = JSON.parse(await fs.readFile('src/data/samples/entities.json','utf8'));
const validate = ajv.compile(entitySchema);
for (const e of entities) {
  const ok = validate(e);
  if (!ok) { console.error(validate.errors); process.exitCode = 1; }
}
console.log('Validation complete.');
