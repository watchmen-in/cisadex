// scripts/etl/normalize_advisories.mjs
import fs from 'node:fs/promises';
import path from 'node:path';
const out = { items: [ { id:'adv-001', title:'Example CISA Advisory', source:'CISA', source_url:'https://www.cisa.gov/news', published:new Date().toISOString(), summary:'Sample advisory', tags:['ransomware'], cves:['CVE-2025-0001'], sha256:'dummy' } ] };
await fs.writeFile(path.resolve('src/data/samples/advisories.json'), JSON.stringify(out, null, 2));
console.log('Wrote normalized advisories.');
