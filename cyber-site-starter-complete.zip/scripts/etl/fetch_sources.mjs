// scripts/etl/fetch_sources.mjs
import fs from 'node:fs/promises';
import path from 'node:path';
const outDir = path.resolve('src/data/raw');
await fs.mkdir(outDir, { recursive: true });
await fs.writeFile(path.join(outDir, 'README.md'), '# Raw source dumps go here');
console.log('Created raw data directory.');
