const palette = document.createElement('dialog');
palette.className = 'cmdk';
palette.innerHTML = `
  <form method="dialog">
    <input type="search" placeholder="Type a command… (e.g., 'map', 'catalog')" aria-label="Command search">
    <menu>
      <button value="map">Go to Map</button>
      <button value="catalog">Go to Catalog</button>
      <button value="advisories">Go to Advisories</button>
      <button value="data">Go to Data Portal</button>
      <button value="about">Go to About</button>
    </menu>
  </form>`;
document.body.appendChild(palette);
window.addEventListener('open-cmdk', () => palette.showModal());
palette.addEventListener('close', () => document.getElementById('cmdkBtn')?.focus());
palette.addEventListener('click', (e) => { if (e.target.tagName === 'BUTTON') {
  const val = e.target.value;
  const map = { map:'/map.html', catalog:'/catalog.html', advisories:'/advisories.html', data:'/data.html', about:'/about.html' };
  window.location.href = map[val] || '/';
}});
document.getElementById('cmdkBtn')?.addEventListener('click', () => palette.showModal());
