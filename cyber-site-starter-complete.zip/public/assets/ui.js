const toggle = (btnId) => {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  btn.addEventListener('click', () => {
    const html = document.documentElement;
    html.dataset.theme = html.dataset.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('theme', html.dataset.theme);
  });
};
toggle('themeToggle');
const savedTheme = localStorage.getItem('theme'); if (savedTheme) document.documentElement.dataset.theme = savedTheme;

const hamburger = document.getElementById('hamburger');
const mobile = document.getElementById('mobileMenu');
if (hamburger && mobile) {
  hamburger.addEventListener('click', () => {
    const isHidden = mobile.hasAttribute('hidden');
    if (isHidden) mobile.removeAttribute('hidden'); else mobile.setAttribute('hidden','');
    hamburger.setAttribute('aria-expanded', String(isHidden));
    if (!isHidden) hamburger.focus(); else mobile.querySelector('a,button')?.focus();
  });
  document.getElementById('mobileThemeToggle')?.addEventListener('click', () => document.getElementById('themeToggle').click());
}

window.addEventListener('keydown', (e) => {
  const metaK = (e.key.toLowerCase() === 'k' && (e.metaKey || e.ctrlKey));
  if (metaK) { e.preventDefault(); window.dispatchEvent(new CustomEvent('open-cmdk')); }
  if (e.key === '/') { const s = document.querySelector('input[type="search"]'); s?.focus(); }
});
