// Placeholder map wiring; replace with MapLibre GL.
const mapShell = document.getElementById('map');
mapShell.innerHTML = '<div style="padding:1rem">Map placeholder. Add MapLibre GL JS and data source.</div>';
document.getElementById('exportCsv').addEventListener('click', ()=>alert('CSV export stub'));
document.getElementById('exportGeo').addEventListener('click', ()=>alert('GeoJSON export stub'));
