async function load() {
  const res = await fetch('/api/v1/search?q=');
  const data = await res.json();
  const el = document.getElementById('catalogResults');
  el.innerHTML = '<table><thead><tr><th>Name</th><th>Type</th><th>Sector</th><th>Region</th></tr></thead><tbody>' +
    data.results.slice(0,50).map(r=>`<tr><td>${r.name}</td><td>${r.type}</td><td>${r.sector}</td><td>${r.region||''}</td></tr>`).join('') +
    '</tbody></table>';
  const input = document.getElementById('catalogSearch');
  input.addEventListener('input', async (e)=>{
    const rq = e.target.value;
    const r = await fetch('/api/v1/search?q=' + encodeURIComponent(rq));
    const d = await r.json();
    el.querySelector('tbody').innerHTML = d.results.slice(0,200).map(r=>`<tr><td>${r.name}</td><td>${r.type}</td><td>${r.sector}</td><td>${r.region||''}</td></tr>`).join('');
  });
}
load();
