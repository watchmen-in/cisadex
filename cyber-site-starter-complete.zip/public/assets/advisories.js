async function load() {
  const res = await fetch('/api/v1/advisories');
  const data = await res.json();
  const el = document.getElementById('advisoryList');
  el.innerHTML = data.items.map(a=>`
    <article>
      <h4><a href="${a.source_url}" target="_blank" rel="noopener">${a.title}</a></h4>
      <p>${a.summary||''}</p>
      <small>${a.published} • ${a.source} • Tags: ${(a.tags||[]).join(', ')}</small>
    </article>`).join('');
}
load();
