export async function onRequest() {
  return new Response(JSON.stringify({items:[
    {"date":"2025-08-11","note":"Initial public scaffold with APIs, feeds, schemas, and UI."}
  ]}), { headers: { "content-type":"application/json; charset=utf-8" } });
}
