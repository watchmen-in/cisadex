import entities from '../../../src/data/samples/entities.json' assert { type: 'json' };
import advisories from '../../../src/data/samples/advisories.json' assert { type: 'json' };
export async function onRequest() {
  return new Response(JSON.stringify({
    entities: entities.length,
    advisories: advisories.items.length,
    datasets: 1
  }), { headers: { "content-type":"application/json; charset=utf-8", "cache-control":"public, max-age=300" } });
}
