import entities from '../../../src/data/samples/entities.json' assert { type: 'json' };
export async function onRequest({ request }) {
  const url = new URL(request.url);
  const q = (url.searchParams.get('q') || '').toLowerCase();
  const results = entities.filter(e => !q || e.name.toLowerCase().includes(q) || e.type.includes(q) || (e.sector||'').includes(q));
  return new Response(JSON.stringify({ query:q, count:results.length, results }), { headers: { "content-type":"application/json; charset=utf-8", "cache-control":"public, max-age=60" } });
}
