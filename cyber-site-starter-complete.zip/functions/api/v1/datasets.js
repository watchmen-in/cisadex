export async function onRequest() {
  const datasets = [
    {"id":"ds-entities","name":"Entities sample","description":"Sample entities dataset","schema":"/src/data/schemas/entity.schema.v1.json",
     "provenance":{"source_url":"https://example.org","update_cadence":"ad-hoc","hash":"dummy"}}
  ];
  return new Response(JSON.stringify({items:datasets}), { headers: { "content-type":"application/json; charset=utf-8" } });
}
