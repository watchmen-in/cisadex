export async function onRequest(context) {
  const base = new URL(context.request.url);
  return new Response(JSON.stringify({
    ok: true,
    endpoints: {
      stats: new URL('./stats', base).pathname,
      search: new URL('./search', base).pathname,
      advisories: new URL('./advisories', base).pathname,
      datasets: new URL('./datasets', base).pathname,
      changelog: new URL('./changelog', base).pathname
    }
  }), { headers: { "content-type":"application/json; charset=utf-8" } });
}
