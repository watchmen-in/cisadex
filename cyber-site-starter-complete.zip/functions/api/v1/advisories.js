import data from '../../../src/data/samples/advisories.json' assert { type: 'json' };
export async function onRequest() {
  return new Response(JSON.stringify(data), { headers: { "content-type":"application/json; charset=utf-8", "cache-control":"public, max-age=120" } });
}
