export const onRequest = async ({ request, env, next }) => {
  const res = await next();
  const newHeaders = new Headers(res.headers);
  newHeaders.set("Content-Security-Policy",
    "default-src 'self' https://cdn.jsdelivr.net; img-src 'self' data: https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; script-src 'self'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'");
  newHeaders.set("Referrer-Policy", "strict-origin-when-cross-origin");
  newHeaders.set("Permissions-Policy", "geolocation=(), microphone=(), camera=()");
  newHeaders.set("X-Content-Type-Options", "nosniff");
  newHeaders.set("X-Frame-Options", "DENY");
  newHeaders.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload");
  return new Response(res.body, {status: res.status, statusText: res.statusText, headers: newHeaders});
};
